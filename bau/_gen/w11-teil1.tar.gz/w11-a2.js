'use strict';
const fs = require('fs');
const S = {
  datei: 'Unterricht-ab-14-09/w11-a-teil2-bezahlen-sparen-a2b1.html',
  eyebrow: 'deutschoderwas · Sprechclub · Woche 11 · Strang A · Teil 2 · Mittwoch, 25. November',
  titel: 'Bezahlen und sparen:',
  hl: 'zusammen oder getrennt?',
  stufe: 'A2/B1',
  termin: 'Mi 25.11. 9:00 · Strang A · Teil 2 · A2 ⇄ B1',
  untertitel: 'An der Kasse, im Restaurant, beim Pfandautomaten: Überall wird kurz über Geld geredet, und meistens sind es dieselben fünf Sätze. Heute übst du sie — und dazu die Vergleiche, mit denen man sagt, was billiger, besser oder am günstigsten ist.',
  fuss: 'Bezahlen und sparen · Teil 2 · A2/B1 · Woche 11 · danach macht der Sprechclub eine Pause',
  niveau: { a: 'A2 · einfacher', b: 'B1 · mehr', hinweis: 'Gleiches Thema, andere Sätze. Wechsle jederzeit — probier ruhig beide Seiten aus.' },

  einstieg: [
    {
      h2: 'Zusammen',
      hl: 'oder getrennt?',
      ssub: 'Diese eine Frage kommt in jedem deutschen Restaurant. Und sie ist keine Höflichkeitsfloskel: Getrennt zahlen ist hier völlig normal, auch bei acht Leuten. Die Bedienung rechnet dann für jeden einzeln aus. In vielen Ländern wäre das undenkbar.',
      bild: 'amanda/sz-restaurant.webp',
      alt: 'Ein Restauranttisch mit Tellern und einer Rechnung',
      fragenA2: [
        'Zahlst du lieber zusammen oder getrennt?',
        'Wie viel Trinkgeld gibst du?',
        'Was hast du zuletzt bar bezahlt?'
      ],
      fragenB1: [
        'Wie läuft das Bezahlen im Restaurant in deinem Land?',
        'Was war für dich am Anfang hier ungewohnt beim Geld?',
        'Wo sparst du, ohne dass es wehtut?'
      ],
      tipp: { art: 'teal', text: '🔑 <strong>Die drei Sätze für jedes Restaurant:</strong> <b>Zahlen bitte.</b> — <b>Getrennt, bitte.</b> — <b>Machen Sie zwanzig.</b> (bei 18,50, dann ist das Trinkgeld dabei). Mehr brauchst du wirklich nicht.' }
    },
    {
      h2: 'Und das Pfand',
      hl: 'ist kein Trinkgeld',
      ssub: 'Auf fast jeder Flasche liegt <b>Pfand</b> — 25 Cent auf die Plastikflasche, 8 Cent auf die Bierflasche. Das ist kein Preis, sondern geliehenes Geld: Bring die Flasche zurück, bekomm den Betrag wieder. Wer das nicht weiß, wirft in Deutschland jedes Jahr eine Menge Geld weg.',
      bild: 'amanda/sz-supermarkt.webp',
      alt: 'Regale im Supermarkt mit Getränkeflaschen',
      fragenA2: [
        'Bringst du deine Flaschen zurück?',
        'Wie viel Pfand ist auf einer Flasche?',
        'Kaufst du oft im Angebot?'
      ],
      fragenB1: [
        'Wie ist das mit Flaschen in deinem Land geregelt?',
        'Lohnt sich das Sammeln überhaupt?',
        'Worauf achtest du beim Einkaufen zuerst — Preis oder Qualität?'
      ],
      tipp: { art: 'yellow', text: '💡 <strong>Gut zu wissen:</strong> Der Pfandautomat druckt einen Bon. Den gibst du an der Kasse ab, und der Betrag wird vom Einkauf abgezogen — oder du bekommst ihn bar. Der Satz dazu: <b>Ich habe noch einen Pfandbon.</b>' }
    }
  ],

  wortschatz: {
    h2: 'Zwölf Wörter,',
    hl: 'die an der Kasse fallen',
    ssub: 'Sag jedes Wort laut — mit Artikel. Und lies bei jedem den Tipp, dort steht der Satz, den du wirklich brauchst.',
    karten: [
      { bild: 'vok-bild/der-euro.webp', alt: 'Euroscheine und Münzen', art: 'das', wort: 'Bargeld', kurz: 'Scheine und Münzen zum Anfassen', bsp: 'Ich habe leider kein Bargeld dabei.', tipp: 'In Deutschland brauchst du öfter Bargeld als anderswo — beim Bäcker, auf dem Markt, in kleinen Kneipen. Der Satz an der Tür: <b>Nehmen Sie Karte?</b>', say: 'Ich habe leider kein Bargeld dabei.' },
      { bild: 'amanda/sz-kasse.webp', alt: 'Eine Kasse im Supermarkt', art: 'die', wort: 'Kasse', kurz: 'die Stelle, an der du bezahlst', bsp: 'An der Kasse war heute richtig viel los.', tipp: 'Zwei feste Sätze: <b>Zahlen Sie bar oder mit Karte?</b> und <b>Möchten Sie den Bon?</b> Beide hörst du in Deutschland täglich.', say: 'An der Kasse war heute richtig viel los.' },
      { bild: 'vok-bild/was-kostet-das.webp', alt: 'Ein Preisschild an einer Ware', art: 'der', wort: 'Preis', kurz: 'wie viel etwas kostet', bsp: 'Der Preis steht klein auf dem Schild.', tipp: 'Achte im Supermarkt auf den <b>Grundpreis</b> — der Preis pro Kilo oder Liter, klein unter dem großen Preis. Damit vergleichst du in zwei Sekunden.', say: 'Der Preis steht klein auf dem Schild.' },
      { bild: 'vok-bild/die-rechnung.webp', alt: 'Eine Rechnung auf einem Tisch', art: 'die', wort: 'Rechnung', kurz: 'das Papier mit dem Betrag, den du zahlst', bsp: 'Können wir bitte die Rechnung haben?', tipp: 'Im Restaurant sagt man kürzer: <b>Zahlen bitte.</b> Und wenn ihr euch teilen wollt: <b>Getrennt, bitte.</b> — zwei Wörter, und alle verstehen.', say: 'Können wir bitte die Rechnung haben?' },
      { bild: 'vok-bild/der-kassenbon.webp', alt: 'Eine Hand hält einen Kassenbon', art: 'der', wort: 'Kassenbon', kurz: 'der schmale Zettel von der Kasse', bsp: 'Ohne Kassenbon kann ich das nicht umtauschen.', tipp: 'Heb ihn auf, solange du etwas zurückgeben könntest. Andere Wörter dafür: der <b>Kassenzettel</b>, der <b>Beleg</b>. Alle drei meinen dasselbe.', say: 'Ohne Kassenbon kann ich das nicht umtauschen.' },
      { bild: 'vok-bild/der-lieferschein.webp', alt: 'Ein Beleg mit Stempel', art: 'die', wort: 'Quittung', kurz: 'der offizielle Beleg, dass du bezahlt hast', bsp: 'Könnte ich bitte eine Quittung bekommen?', tipp: 'Beim Handwerker, beim Taxi, im Hotel: <b>Könnte ich bitte eine Quittung bekommen?</b> Für die Steuer und im Streitfall ist sie mehr wert als der Bon.', say: 'Könnte ich bitte eine Quittung bekommen?' },
      { bild: 'amanda/sz-restaurant.webp', alt: 'Ein gedeckter Tisch im Restaurant', art: 'das', wort: 'Trinkgeld', kurz: 'das bisschen extra für den Service', bsp: 'Fünf bis zehn Prozent Trinkgeld sind hier üblich.', tipp: 'Man legt es nicht auf den Tisch, sondern sagt beim Zahlen den runden Betrag: bei 18,50 sagst du <b>Machen Sie zwanzig.</b> Damit ist alles erledigt.', say: 'Fünf bis zehn Prozent Trinkgeld sind hier üblich.' },
      { bild: 'amanda/sz-supermarkt.webp', alt: 'Getränkeflaschen im Supermarktregal', art: 'das', wort: 'Pfand', kurz: 'das Geld, das du für die Flasche zurückbekommst', bsp: 'Auf der Flasche sind fünfundzwanzig Cent Pfand.', tipp: 'Kein Preis, sondern geliehenes Geld. Flasche zurück, Geld zurück. Und der Satz an der Kasse lautet: <b>Ich habe noch einen Pfandbon.</b>', say: 'Auf der Flasche sind fünfundzwanzig Cent Pfand.' },
      { bild: 'vok-bild/das-angebot.webp', alt: 'Ein Schild mit einem Sonderangebot', art: 'das', wort: 'Angebot', kurz: 'die Ware, die diese Woche billiger ist', bsp: 'Der Käse ist diese Woche im Angebot.', tipp: '<b>im Angebot</b> — mit <i>im</i>, nicht <i>auf</i>. Und der Prospekt kommt in Deutschland jede Woche in den Briefkasten; darin steht, was ab Montag günstiger ist.', say: 'Der Käse ist diese Woche im Angebot.' },
      { bild: 'amanda/sz-handel.webp', alt: 'Ein Laden mit Preisschildern', art: 'der', wort: 'Rabatt', kurz: 'wie viel Prozent du weniger zahlst', bsp: 'Auf alles zwanzig Prozent Rabatt.', tipp: 'Verwechsle es nicht mit dem Angebot: Das <b>Angebot</b> ist die Ware, der <b>Rabatt</b> ist die Zahl. Und im Laden fragt man: <b>Gibt es darauf einen Rabatt?</b>', say: 'Auf alles zwanzig Prozent Rabatt.' },
      { bild: 'amanda/sz-buchhaltung.webp', alt: 'Zahlen und Belege auf einem Schreibtisch', art: 'die', wort: 'Ausgaben', kurz: 'alles, was du im Monat ausgibst', bsp: 'Meine größten Ausgaben sind Miete und Essen.', tipp: 'Immer Plural. Das Gegenstück heißt <b>die Einnahmen</b>. Und ein guter Satz für jedes Gespräch über Geld: <i>Da geht mehr weg, als ich dachte.</i>', say: 'Meine größten Ausgaben sind Miete und Essen.' },
      { bild: 'vok-bild/die-gebuehr.webp', alt: 'Münzen liegen neben einem Formular', art: 'die', wort: 'Rate', kurz: 'ein Teil vom Preis, den du jeden Monat zahlst', bsp: 'Ich zahle das Sofa in zwölf Raten ab.', tipp: 'Das Verb ist <b>abzahlen</b>, trennbar. Und pass auf: <i>null Prozent Finanzierung</i> klingt geschenkt, ist aber oft teurer als der Preis ohne Raten.', say: 'Ich zahle das Sofa in zwölf Raten ab.' }
    ],
    spiel: { text: '💡 <strong>Spiel „Was ist billiger?“:</strong> Einer nennt zwei Dinge — <i>Bahn oder Auto</i>, <i>kochen oder bestellen</i>, <i>Markt oder Supermarkt</i>. Der andere vergleicht sie in einem Satz mit <b>billiger als</b> und sagt einen Grund dazu.' }
  },

  konzepte: {
    tab: '🔍 Drei Belege',
    zuerst: 'dreier',
    h2: 'Bon, Quittung',
    hl: 'oder Rechnung?',
    ssub: 'Drei Zettel, die leicht durcheinandergehen. Der Unterschied ist einfach: Wie offiziell muss es sein?',
    dreier: [
      { emoji: '🧾', wort: 'der Kassenbon', was: 'der schmale Zettel aus der Kasse', bsp: 'Zum <b>Umtauschen</b> im Laden — heb ihn zwei Wochen auf.' },
      { emoji: '🖊️', wort: 'die Quittung', was: 'mit Datum, Betrag und Unterschrift', bsp: 'Beim <b>Handwerker</b> oder <b>Taxi</b> — und für die Steuer.' },
      { emoji: '📄', wort: 'die Rechnung', was: 'kommt vorher, du zahlst danach', bsp: 'Vom <b>Arzt</b>, vom <b>Strom</b>, aus dem <b>Restaurant</b>.' }
    ],
    paare: [
      {
        jaLabel: 'So ist es richtig', ja: 'Der Käse ist diese Woche im Angebot.',
        jaWarumLabel: 'Warum das stimmt', jaWarum: 'Die feste Wendung heißt <b>im Angebot</b> — mit <i>im</i>, also Dativ. Genauso: <i>im Sonderangebot</i>, <i>im Sale</i>.',
        noLabel: 'So klingt es falsch', no: 'Der Käse ist diese Woche auf Angebot.',
        noWarumLabel: 'Das Problem', noWarum: 'Im Englischen steht dort <i>on</i>, deshalb rutscht <i>auf</i> heraus. Auf Deutsch heißt es <b>im</b> Angebot — und <b>reduziert</b> geht auch: <i>Der Käse ist reduziert.</i>'
      },
      {
        jaLabel: 'So ist es richtig', ja: 'Kochen ist billiger als bestellen.',
        jaWarumLabel: 'Warum das stimmt', jaWarum: 'Beim Vergleich steht <b>als</b>: <i>billiger <b>als</b></i>, <i>besser <b>als</b></i>, <i>teurer <b>als</b></i>. Nur wenn zwei Dinge gleich sind, steht <b>wie</b>: <i>genauso teuer <b>wie</b></i>.',
        noLabel: 'So klingt es falsch', no: 'Kochen ist billiger wie bestellen.',
        noWarumLabel: 'Das Problem', noWarum: 'Man hört das in Deutschland oft, auch von Deutschen — richtig ist es trotzdem nicht. Merk dir das Paar: <b>-er … als</b> für Unterschied, <b>so … wie</b> für Gleichheit.'
      },
      {
        jaLabel: 'So ist es richtig', ja: 'Achtzehn fünfzig? Machen Sie zwanzig.',
        jaWarumLabel: 'Warum das stimmt', jaWarum: 'So gibt man in Deutschland Trinkgeld: Du nennst beim Zahlen den runden Betrag, die Bedienung nimmt die Differenz. Kein Geld auf dem Tisch, keine Rechnerei.',
        noLabel: 'So wird es unangenehm', no: 'Hier ist das Geld, den Rest lege ich Ihnen dann später hin.',
        noWarumLabel: 'Das Problem', noWarum: 'Das kennt hier niemand, und es macht die Situation kompliziert. Ein Satz genügt: <b>Machen Sie zwanzig.</b> Oder, wenn es genau passen soll: <b>Stimmt so.</b>'
      }
    ],
    hilfe: {
      knopf: '🆘 Wie sage ich das an der Kasse?',
      vor: 'Vier Sätze, mehr brauchst du nie:',
      punkte: [
        '<b>Im Restaurant:</b> <i>Zahlen bitte.</i> Und dann: <i>Zusammen</i> oder <i>Getrennt, bitte.</i>',
        '<b>Trinkgeld:</b> Nenn den runden Betrag — <i>Machen Sie zwanzig.</i> Oder: <i>Stimmt so.</i>',
        '<b>Im Laden:</b> <i>Kann ich mit Karte zahlen?</i> Und: <i>Den Bon bitte.</i>',
        '<b>Beim Pfand:</b> <i>Ich habe noch einen Pfandbon.</i>'
      ],
      nach: 'Und wenn du den Betrag nicht verstanden hast: frag einfach nach. <i>Wie viel war das noch mal?</i> Das fragen auch Deutsche ständig, weil an der Kasse alle nuscheln.'
    },
    tipp: { art: 'yellow', text: '🎯 <strong>Zu zweit, zwei Minuten:</strong> Einer spielt die Kasse und nennt einen Betrag — <i>achtzehn fünfzig</i>, <i>sieben neunzig</i>. Der andere zahlt, gibt Trinkgeld und fragt nach dem Bon.' }
  },

  saetze: {
    h2: 'Vier Bausteine',
    hl: 'für jede Kasse',
    ssub: 'Fragen, was es kostet. Sagen, wie du zahlst. Vergleichen. Und höflich nachfragen, wenn etwas nicht stimmt.',
    akkLabel: 'der Schritt',
    mengeLabel: 'was du damit erreichst',
    a2: [
      { titel: '1 · 💶 Nach dem Preis fragen', chips: ['Was kostet das?', 'Wie viel macht das zusammen?', 'Ist das im Angebot?', 'Ist da Pfand drauf?'], bsp: 'Was kostet das, und ist da Pfand drauf?', say: 'Was kostet das, und ist da Pfand drauf?' },
      { titel: '2 · 💳 Sagen, wie du zahlst', chips: ['Mit Karte, bitte.', 'Ich zahle bar.', 'Zusammen, bitte.', 'Getrennt, bitte.'], bsp: 'Getrennt, bitte. Ich zahle mit Karte.', say: 'Getrennt, bitte. Ich zahle mit Karte.' },
      { titel: '3 · ⚖️ Vergleichen', chips: ['Das ist billiger als …', 'Der hier ist besser.', 'Das ist am günstigsten.', 'Ich nehme lieber den kleinen.'], bsp: 'Der große ist billiger als zwei kleine — ich nehme den großen.', say: 'Der große ist billiger als zwei kleine — ich nehme den großen.' },
      { titel: '4 · 🙋 Nachfragen', chips: ['Wie viel war das noch mal?', 'Stimmt das so?', 'Da fehlt noch mein Pfandbon.', 'Den Bon bitte.'], bsp: 'Entschuldigung, da fehlt noch mein Pfandbon.', say: 'Entschuldigung, da fehlt noch mein Pfandbon.' }
    ],
    b1: [
      { titel: '1 · 💶 Genau nachfragen', chips: ['Ist der Preis pro Stück oder pro Kilo?', 'Gilt das Angebot noch?', 'Gibt es darauf einen Rabatt?', 'Ist das Pfand im Preis enthalten?'], bsp: 'Ist der Preis pro Stück oder pro Kilo — und gilt das Angebot noch bis Samstag?', say: 'Ist der Preis pro Stück oder pro Kilo — und gilt das Angebot noch bis Samstag?' },
      { titel: '2 · 💳 Beim Zahlen klar sein', chips: ['Wir zahlen getrennt, jeder für sich.', 'Machen Sie bitte zwanzig.', 'Könnte ich eine Quittung bekommen?', 'Kann ich in Raten zahlen?'], bsp: 'Wir zahlen getrennt — und machen Sie bei mir bitte zwanzig.', say: 'Wir zahlen getrennt — und machen Sie bei mir bitte zwanzig.' },
      { titel: '3 · ⚖️ Begründet vergleichen', chips: ['Auf den Kilopreis gerechnet ist … günstiger.', 'Das lohnt sich nur, wenn …', 'Unterm Strich kommt … billiger.', 'Am meisten spare ich bei …'], bsp: 'Auf den Kilopreis gerechnet ist die große Packung günstiger — aber nur, wenn ich sie auch aufbrauche.', say: 'Auf den Kilopreis gerechnet ist die große Packung günstiger — aber nur, wenn ich sie auch aufbrauche.' },
      { titel: '4 · 🙋 Freundlich reklamieren', chips: ['Da stimmt etwas nicht mit dem Betrag.', 'An der Kasse war ein anderer Preis ausgezeichnet.', 'Könnten Sie das bitte noch mal prüfen?', 'Ich habe den Bon dabei.'], bsp: 'Da stimmt etwas nicht: Am Regal stand ein anderer Preis. Könnten Sie das bitte prüfen?', say: 'Da stimmt etwas nicht: Am Regal stand ein anderer Preis. Könnten Sie das bitte prüfen?' }
    ],
    tipp: { art: 'teal', text: '📣 <strong>Reihum:</strong> Jeder nennt eine Sache, die er diese Woche gekauft hat, und vergleicht sie in einem Satz mit einer Alternative — <i>billiger als</i>, <i>besser als</i>, <i>am günstigsten</i>.' }
  },

  dialoge: {
    h2: 'Vier Situationen —',
    hl: 'zwei Runden',
    ssub: '<b>Runde 1:</b> Lest den Dialog zu zweit laut. <b>Runde 2:</b> Klappt die Zeilen zu und sprecht frei — nur die Stichwörter bleiben.',
    liste: [
      {
        bild: 'amanda/sz-restaurant.webp', alt: 'Ein Tisch im Restaurant mit Gläsern und einer Rechnung',
        titel: 'Zahlen bitte',
        situation: 'A und B haben zusammen gegessen und wollen zahlen. Die Bedienung fragt das Übliche.',
        zeilen: [
          { wer: 'a', text: 'Zahlen bitte! Wir machen das getrennt.' },
          { wer: 'b', text: 'Gern. Was hatten Sie beide? Ich rechne es einzeln aus.', cue: '<b>getrennt zahlen</b> ist hier völlig normal. Und die Bedienung rechnet wirklich für jeden einzeln — auch bei acht Leuten.' },
          { wer: 'a', text: 'Ich hatte die Suppe und ein Wasser.' },
          { wer: 'b', text: 'Das macht bei Ihnen zwölf achtzig.', cue: 'So spricht man Beträge: <b>zwölf achtzig</b> für 12,80 — ohne <i>Euro</i>, ohne <i>Cent</i>. Genauso an jeder Kasse.' },
          { wer: 'a', text: 'Machen Sie vierzehn.' },
          { wer: 'b', text: 'Danke schön! Möchten Sie eine Quittung?', cue: '<b>Machen Sie vierzehn</b> — so gibt man Trinkgeld. Und die Frage nach der <b>Quittung</b> kommt oft; für die Steuer brauchst du sie.' }
        ]
      },
      {
        bild: 'amanda/sz-supermarkt.webp', alt: 'Ein Supermarkt mit Getränkeregalen',
        titel: 'Am Pfandautomaten',
        situation: 'A hat einen Beutel Flaschen dabei und weiß nicht, wie es funktioniert. B arbeitet im Laden.',
        zeilen: [
          { wer: 'a', text: 'Entschuldigung, kann ich hier alle Flaschen zurückgeben?' },
          { wer: 'b', text: 'Die mit dem Pfandzeichen ja. Die anderen nimmt der Automat nicht.', cue: '<b>zurückgeben</b> — trennbar. Und das <b>Pfandzeichen</b> ist der kleine Aufdruck; ohne ihn gibt es kein Geld.' },
          { wer: 'a', text: 'Und was mache ich mit dem Zettel danach?' },
          { wer: 'b', text: 'Den geben Sie an der Kasse ab. Der Betrag wird vom Einkauf abgezogen.', cue: '<b>abgeben</b> und <b>abziehen</b> — beide trennbar. Und wenn du nichts kaufst, bekommst du das Geld bar.' },
          { wer: 'a', text: 'Wie viel ist das ungefähr bei zwanzig Flaschen?' },
          { wer: 'b', text: 'Fünf Euro, wenn es Plastikflaschen sind. Bei Bier deutlich weniger.', cue: 'Zahlen im Alltag. Und die Regel dahinter: 25 Cent auf Plastik, 8 Cent auf Bier — <b>deutlich weniger</b>.' }
        ]
      },
      {
        bild: 'vok-bild/das-angebot.webp', alt: 'Ein Angebotsschild im Laden',
        titel: 'Der Preis am Regal',
        situation: 'A hat an der Kasse mehr bezahlt als am Regal stand. B ist die Kassiererin.',
        zeilen: [
          { wer: 'a', text: 'Entschuldigung, da stimmt etwas nicht. Am Regal stand ein anderer Preis.' },
          { wer: 'b', text: 'Das kann passieren. Wissen Sie noch, was dort ausgezeichnet war?', cue: '<b>ausgezeichnet</b> heißt hier: mit einem Preisschild versehen. Ein Wort, das man nur im Laden hört.' },
          { wer: 'a', text: 'Zwei neunundneunzig. Hier steht drei neunundvierzig.' },
          { wer: 'b', text: 'Dann bekommen Sie die Differenz zurück. Ich schaue eben nach.', cue: '<b>die Differenz</b> — der Unterschied zwischen zwei Beträgen. Und in Deutschland gilt: Was am Regal steht, zählt.' },
          { wer: 'a', text: 'Danke. Ich habe den Bon hier.' },
          { wer: 'b', text: 'Perfekt, den brauche ich. Fünfzig Cent, bitte sehr.', cue: 'Ohne <b>Bon</b> wird es schwierig — deshalb lohnt es sich, ihn bis nach dem Einpacken in der Hand zu behalten.' }
        ]
      },
      {
        bild: 'amanda/sz-buchhaltung.webp', alt: 'Ein Notizbuch mit Zahlen und ein Taschenrechner',
        titel: 'Wo geht das Geld hin?',
        situation: 'A und B reden über die Ausgaben im Monat. Beide vergleichen und rechnen laut.',
        zeilen: [
          { wer: 'a', text: 'Ich weiß am Monatsende nie, wo das Geld geblieben ist.' },
          { wer: 'b', text: 'Bei mir war es genauso. Seit ich alles aufschreibe, sehe ich es sofort.', cue: '<b>aufschreiben</b> — trennbar. Und <i>bei mir war es genauso</i> ist der freundlichste Weg, ein Gespräch über Geld zu öffnen.' },
          { wer: 'a', text: 'Und was ist bei dir am teuersten?' },
          { wer: 'b', text: 'Die Miete natürlich. Danach kommt Essen, das ist teurer als ich dachte.', cue: 'Zwei Vergleiche in einem Satz: <b>am teuersten</b> und <b>teurer als</b>. Genau das üben wir gleich.' },
          { wer: 'a', text: 'Selbst kochen ist doch aber billiger als bestellen, oder?' },
          { wer: 'b', text: 'Deutlich. Aber nur, wenn man wirklich alles aufbraucht.', cue: '<b>billiger als</b> — beim Unterschied steht immer <i>als</i>, nie <i>wie</i>. Und <i>aufbrauchen</i> ist wieder trennbar.' }
        ]
      }
    ],
    tipp: { art: 'yellow', text: '🎭 <strong>Und jetzt ihr:</strong> Spielt Dialog 1 mit einer echten Rechnung. Regel: Es müssen ein Betrag, ein Trinkgeld und die Frage nach dem Bon vorkommen.' }
  },

  grammatik: {
    h2: '🧩 Billig, billiger,',
    hl: 'am billigsten',
    ssub: 'Wer über Preise redet, vergleicht ständig. Dafür brauchst du drei Stufen — und vier Wörter, die nicht der Regel folgen.',
    intro: 'Die Regel ist kurz: <b>-er</b> für den Vergleich, <b>am -sten</b> für den Höchstwert. <i>billig — billiger — am billigsten</i>. Und beim Vergleich steht immer <b>als</b>, nie <i>wie</i>: <i>billiger <b>als</b></i>.',
    kette: [
      { emoji: '1️⃣', rolle: 'Grundform', bsp: 'billig' },
      { emoji: '2️⃣', rolle: 'Vergleich', bsp: 'billiger als' },
      { emoji: '3️⃣', rolle: 'Höchstwert', bsp: 'am billigsten' },
      { emoji: '🟰', rolle: 'gleich', bsp: 'genauso billig wie' }
    ],
    felder: [
      { rolle: 'Kochen', wort: 'Kochen' },
      { rolle: 'ist', wort: 'ist' },
      { rolle: 'Vergleich', wort: 'billiger', hervor: true },
      { rolle: 'als', wort: 'als bestellen.' }
    ],
    bloecke: [
      {
        h2: 'Vier Wörter',
        hl: 'machen es anders',
        ssub: 'Die musst du einfach auswendig können — dafür kommen sie täglich vor.',
        dreier: [
          { emoji: '👍', wort: 'gut', was: 'besser · am besten', bsp: 'Der Markt ist <b>besser</b> als der Supermarkt.' },
          { emoji: '💰', wort: 'viel', was: 'mehr · am meisten', bsp: 'Für Essen gebe ich <b>am meisten</b> aus.' },
          { emoji: '❤️', wort: 'gern', was: 'lieber · am liebsten', bsp: 'Ich zahle <b>lieber</b> bar.' }
        ],
        chips: ['billig — billiger — am billigsten', 'teuer — teurer — am teuersten', 'günstig — günstiger — am günstigsten', 'gut — besser — am besten', 'viel — mehr — am meisten', 'gern — lieber — am liebsten', 'groß — größer — am größten', 'hoch — höher — am höchsten', 'als', 'genauso … wie', 'deutlich', 'ein bisschen']
      },
      {
        h2: 'als oder wie?',
        hl: 'Ein Wort, ein großer Unterschied',
        ssub: 'Das ist der häufigste Fehler beim Vergleichen — und man hört ihn sofort.',
        paare: [
          {
            jaLabel: 'So ist es richtig', ja: 'Der Markt ist billiger als der Supermarkt. Aber das Brot ist genauso teuer wie dort.',
            jaWarumLabel: 'Warum das stimmt', jaWarum: 'Beim <u>Unterschied</u> steht <b>als</b>: <i>billiger als</i>. Bei <u>Gleichheit</u> steht <b>so … wie</b>: <i>genauso teuer wie</i>. Zwei Muster, mehr gibt es nicht.',
            noLabel: 'So klingt es falsch', no: 'Der Markt ist billiger wie der Supermarkt.',
            noWarumLabel: 'Das Problem', noWarum: 'Das hört man in Deutschland oft, auch von Muttersprachlern — richtig wird es dadurch nicht. Merk dir: Wo ein <b>-er</b> steht, folgt <b>als</b>.'
          }
        ]
      }
    ],
    bauH2: '🧱 Bau die Sätze selbst',
    bauSsub: 'Tippe die Teile in der richtigen Reihenfolge an. Achte darauf, ob <i>als</i> oder <i>wie</i> hingehört.',
    storyH2: '📖 Und jetzt im Zusammenhang',
    storySsub: 'Ein Einkauf am Samstag. Wähle in jeder Lücke die richtige Form.',
    hilfe: {
      knopf: '🆘 Wie vergleiche ich richtig?',
      vor: 'Drei Schritte, dann steht der Satz:',
      punkte: [
        '<b>Ein Unterschied?</b> Dann <b>-er</b> plus <b>als</b>: <i>Kochen ist billig<u>er</u> <b>als</b> bestellen.</i>',
        '<b>Gleich?</b> Dann <b>genauso … wie</b>: <i>Der Käse ist genauso teuer <b>wie</b> letzte Woche.</i>',
        '<b>Der Höchstwert?</b> Dann <b>am … -sten</b>: <i>Am billigsten ist der Markt.</i>',
        '<b>Und die vier Ausnahmen:</b> gut — besser, viel — mehr, gern — lieber, hoch — höher.'
      ],
      nach: 'Und wenn dir die Steigerung nicht einfällt, geht es auch anders herum: <i>Kochen kostet weniger.</i> Oder <i>Bestellen ist teuer, kochen nicht.</i> Zwei kurze Sätze sind immer erlaubt.'
    }
  },

  rollenspiele: {
    h2: '🎭 Drei Situationen',
    hl: 'zu zweit',
    ssub: 'Einer kauft, einer verkauft. Danach tauschen — beim zweiten Mal ohne die Sätze unten. Mindestens ein Vergleich pro Runde.',
    liste: [
      {
        titel: 'Zahlen im Restaurant',
        situation: 'A und B haben zusammen gegessen und wollen getrennt zahlen. Einer von beiden spielt die Bedienung und rechnet einzeln aus.',
        a2: ['Zahlen bitte, wir machen das getrennt', 'Ich hatte die Suppe und ein Wasser', 'Machen Sie vierzehn', 'Könnte ich eine Quittung bekommen?'],
        b1: ['Was hatten Sie beide? Ich rechne es einzeln aus', 'Das macht bei Ihnen zwölf achtzig', 'Zusammen oder getrennt, wie Sie möchten', 'Möchten Sie den Bon oder eine Quittung?'],
        gut: 'Beide haben einen Betrag laut gesagt, das Trinkgeld über den runden Betrag geregelt und einmal nach dem Beleg gefragt.'
      },
      {
        titel: 'Der falsche Preis',
        situation: 'A hat an der Kasse mehr bezahlt, als am Regal stand. B ist die Kassiererin und muss nachschauen.',
        a2: ['Da stimmt etwas nicht mit dem Preis', 'Am Regal stand zwei neunundneunzig', 'Hier steht drei neunundvierzig', 'Ich habe den Bon dabei'],
        b1: ['Wissen Sie noch, was dort ausgezeichnet war?', 'Dann bekommen Sie die Differenz zurück', 'Ich schaue kurz nach, einen Moment bitte', 'Ohne Bon kann ich es leider nicht erstatten'],
        gut: 'A ist ruhig geblieben und hat zwei Beträge genannt. B hat gesagt, was passiert — und beide haben das Wort <i>Bon</i> benutzt.'
      },
      {
        titel: 'Was ist günstiger?',
        situation: 'A und B stehen im Laden vor zwei Packungen und rechnen laut. Einer will die große, der andere die kleine.',
        a2: ['Der große ist billiger als zwei kleine', 'Aber wir brauchen so viel gar nicht', 'Ich nehme lieber den kleinen', 'Was ist am günstigsten?'],
        b1: ['Auf den Kilopreis gerechnet ist die große Packung günstiger', 'Das lohnt sich aber nur, wenn wir alles aufbrauchen', 'Unterm Strich kommen zwei kleine teurer', 'Am meisten sparen wir sowieso beim Angebot'],
        gut: 'Es sind mindestens zwei Vergleiche gefallen — einer mit <i>als</i>, einer mit <i>am … -sten</i>. Und keiner hat <i>billiger wie</i> gesagt.'
      }
    ]
  },

  challenge: {
    ssub: 'Neunzig Sekunden über dein Geld: Was kostet dich am meisten, wo sparst du, und wofür gibst du gern mehr aus?',
    hilfe: {
      knopf: '🆘 Mir fällt nichts ein',
      vor: 'Vier Sätze, dann trägt dich die Zeit:',
      punkte: [
        '<b>Am meisten:</b> <i>Am meisten gebe ich für … aus.</i>',
        '<b>Vergleich:</b> <i>… ist deutlich billiger als …</i>',
        '<b>Gern:</b> <i>Für … zahle ich gern mehr, weil …</i>',
        '<b>Sparen:</b> <i>Sparen könnte ich am ehesten bei …</i>'
      ],
      nach: 'Und wenn du in der Mitte hängst: nimm dasselbe Thema und dreh es um. <i>Früher war das anders — da habe ich …</i> Schon läuft es weiter.'
    },
    tipp: { art: 'yellow', text: '⏱️ <strong>Spielregel:</strong> In jeder Runde müssen <u>zwei Vergleiche</u> vorkommen. Wer <i>billiger wie</i> sagt, fängt noch einmal an.' }
  },

  ueben: { tipp: { art: 'teal', text: '📣 <strong>Danach laut:</strong> Einer nennt zwei Dinge, der Nächste vergleicht sie in einem Satz. Reihum, schnell, ohne lange zu überlegen.' } },

  hausaufgabe: {
    h2: '📮 Deine Hausaufgabe bis',
    hl: 'Freitag',
    ssub: 'Vier kleine Aufgaben, zusammen etwa 25 Minuten. Danach macht der Sprechclub eine Pause — im Lernbereich kannst du weiterüben, so viel du möchtest.',
    warum: { text: '💡 <strong>Warum das hilft:</strong> An der Kasse hat niemand Zeit, und genau deshalb ist es dort so unangenehm, wenn einem die Worte fehlen. Es sind aber immer dieselben fünf Sätze. Wer sie einmal auswendig kann, steht nie wieder mit rotem Kopf an der Kasse.' },
    a2: [
      { emoji: '🧾', titel: 'Dein Kassenbon', zeit: '5 Min', text: 'Nimm einen echten Kassenbon und lies ihn laut vor: Was hast du gekauft, was hat es gekostet, war Pfand dabei?' },
      { emoji: '⚖️', titel: 'Zehn Vergleiche', zeit: '7 Min', text: 'Schreib zehn Sätze mit <i>billiger als</i>, <i>teurer als</i>, <i>besser als</i> — alle aus deinem eigenen Alltag.' },
      { emoji: '🗣️', titel: 'An der Kasse', zeit: '6 Min', text: 'Nimm eine Sprachnachricht auf: Du zahlst im Restaurant getrennt und gibst Trinkgeld. Alle Sätze laut sagen.' },
      { emoji: '🔍', titel: 'Der Prospekt', zeit: '7 Min', text: 'Such einen Werbeprospekt und schreib fünf Sätze darüber, was diese Woche im Angebot ist und ob es sich lohnt.' }
    ],
    b1: [
      { emoji: '📊', titel: 'Deine Ausgaben', zeit: '8 Min', text: 'Schreib in zehn Sätzen auf, wofür dein Geld im Monat draufgeht — mit mindestens vier Vergleichen und einem <i>am meisten</i>.' },
      { emoji: '📝', titel: 'Eine Reklamation', zeit: '6 Min', text: 'Schreib eine kurze Mail an einen Laden: Der Preis an der Kasse war höher als am Regal. Nenne Datum, Betrag und was du möchtest.' },
      { emoji: '🎙️', titel: 'Zwei Minuten Vergleich', zeit: '6 Min', text: 'Nimm auf, wie du zwei Einkaufsmöglichkeiten vergleichst — Markt und Supermarkt, oder online und im Laden. Mit Gründen.' },
      { emoji: '👂', titel: 'Zuhören an der Kasse', zeit: '5 Min', text: 'Achte beim nächsten Einkauf genau auf die Sätze der Kassiererin und notier fünf davon wörtlich.' }
    ],
    hilfeA2: {
      knopf: '💡 Beispiel ansehen (Aufgabe 2)',
      vor: 'So sehen die zehn Sätze aus:',
      punkte: [
        '<i>Kochen ist <b>billiger als</b> bestellen.</i>',
        '<i>Die Bahn ist <b>teurer als</b> der Bus, aber schneller.</i>',
        '<i>Der Markt ist <b>besser als</b> der Supermarkt, finde ich.</i>',
        '<i>Die große Packung ist <b>genauso teuer wie</b> zwei kleine.</i>',
        '<i><b>Am meisten</b> gebe ich für die Miete aus.</i>'
      ],
      nach: 'Ein einziger Test genügt: Steht in deinem Satz ein <b>-er</b>? Dann muss danach <b>als</b> kommen, niemals <i>wie</i>. Und <i>wie</i> steht nur nach <b>genauso</b> oder <b>so</b>.'
    },
    hilfeB1: {
      knopf: '💡 Beispiel ansehen (Aufgabe 2)',
      vor: 'Das sind die Stellen, auf die es in der Mail ankommt:',
      punkte: [
        '<b>Betreff:</b> <i>Preisdifferenz bei meinem Einkauf vom 25.11.</i>',
        '<b>Sache:</b> <i>Am Regal war der Artikel mit 2,99 Euro ausgezeichnet, an der Kasse wurden 3,49 Euro berechnet.</i>',
        '<b>Beleg:</b> <i>Den Kassenbon habe ich aufgehoben, eine Kopie liegt bei.</i>',
        '<b>Wunsch:</b> <i>Ich bitte Sie, mir die Differenz von 50 Cent zu erstatten.</i>',
        '<b>Schluss:</b> <i>Vielen Dank vorab — über eine kurze Rückmeldung würde ich mich freuen.</i>'
      ],
      nach: 'Und ein Hinweis, der wirklich zählt: In Deutschland gilt der Preis, der am Regal steht — jedenfalls dann, wenn du ihn nachweisen kannst. Ohne Bon wird es schwierig, mit Bon fast immer einfach.'
    },
    abgabe: 'Schick mir bis Freitag 12 Uhr deine zehn Vergleiche und die Sprachnachricht — ich sage dir, wo <i>als</i> und <i>wie</i> verrutscht sind.',
    ausblick: 'Danach macht der Sprechclub eine Pause. Im Lernbereich bleibt alles offen: Wortschatz, Grammatik, Hören, Sprechen — und die 90-Sekunden-Wörter aus allen elf Wochen.'
  },

  daten: {
    sk: [
      'Du zahlst im Restaurant getrennt und gibst Trinkgeld. Sag alle Sätze.',
      'Erklär jemandem, wie Pfand in Deutschland funktioniert.',
      'Vergleich Markt und Supermarkt in drei Sätzen.',
      'An der Kasse stimmt der Preis nicht. Sag es höflich.',
      'Wofür gibst du am meisten Geld aus? Und warum?',
      'Erklär den Unterschied zwischen Bon, Quittung und Rechnung.',
      'Nenne drei Dinge, bei denen du nie sparen würdest.',
      'Wie viel Trinkgeld gibt man in deinem Land?',
      'Vergleich zwei Packungen und entscheide dich laut.',
      'Sag fünf Sätze mit <i>billiger als</i> und <i>am günstigsten</i>.'
    ],
    w90: [
      { w: 'das Bargeld', b: 'vok-bild/der-euro.webp', h: ['bar', 'der Schein', 'die Münze', 'abheben', 'dabeihaben'] },
      { w: 'die Kasse', b: 'amanda/sz-kasse.webp', h: ['bezahlen', 'anstehen', 'der Bon', 'die Karte', 'einpacken'] },
      { w: 'der Preis', b: 'vok-bild/was-kostet-das.webp', h: ['kosten', 'das Schild', 'teuer', 'vergleichen', 'pro Kilo'] },
      { w: 'die Rechnung', b: 'vok-bild/die-rechnung.webp', h: ['zahlen', 'getrennt', 'zusammen', 'der Betrag', 'bitten'] },
      { w: 'der Kassenbon', b: 'vok-bild/der-kassenbon.webp', h: ['der Zettel', 'aufheben', 'umtauschen', 'der Beleg', 'die Kasse'] },
      { w: 'das Trinkgeld', b: 'amanda/sz-restaurant.webp', h: ['aufrunden', 'die Bedienung', 'stimmt so', 'zehn Prozent', 'freiwillig'] },
      { w: 'das Pfand', b: 'amanda/sz-supermarkt.webp', h: ['die Flasche', 'zurückgeben', 'der Automat', 'fünfundzwanzig Cent', 'der Bon'] },
      { w: 'das Angebot', b: 'vok-bild/das-angebot.webp', h: ['billiger', 'diese Woche', 'der Prospekt', 'reduziert', 'zugreifen'] },
      { w: 'der Rabatt', b: 'amanda/sz-handel.webp', h: ['Prozent', 'weniger zahlen', 'die Aktion', 'fragen', 'der Preis'] },
      { w: 'die Ausgaben', b: 'amanda/sz-buchhaltung.webp', h: ['im Monat', 'die Miete', 'aufschreiben', 'sparen', 'der Überblick'] }
    ],
    quiz: [
      { q: 'Was sagst du im Restaurant, wenn jeder für sich zahlt?', o: ['Getrennt, bitte.', 'Zusammen, bitte.', 'Alles auf eine Rechnung.', 'Nur bar, bitte.'], c: 0, e: 'Getrennt zahlen ist in Deutschland völlig normal, auch bei vielen Leuten. Die Bedienung rechnet dann einzeln aus.' },
      { q: 'Wie gibst du Trinkgeld bei 18,50 Euro?', o: ['Machen Sie zwanzig.', 'Ich lege es später auf den Tisch.', 'Bitte rechnen Sie zehn Prozent dazu.', 'Behalten Sie alles.'], c: 0, e: 'Du nennst beim Zahlen den runden Betrag. Wenn es genau passen soll, sagst du <b>Stimmt so.</b>' },
      { q: 'Welcher Satz ist richtig?', o: ['Kochen ist billiger als bestellen.', 'Kochen ist billiger wie bestellen.', 'Kochen ist billig als bestellen.', 'Kochen ist mehr billig als bestellen.'], c: 0, e: 'Wo ein <b>-er</b> steht, folgt <b>als</b>. <i>wie</i> steht nur nach <i>genauso</i> oder <i>so</i>.' },
      { q: 'Was ist <u>Pfand</u>?', o: ['geliehenes Geld, das du für die Flasche zurückbekommst', 'ein Rabatt auf Getränke', 'eine Gebühr für die Kasse', 'das Trinkgeld im Supermarkt'], c: 0, e: 'Flasche zurück, Geld zurück. 25 Cent auf Plastik, 8 Cent auf Bier — und der Automat druckt dir einen Bon.' },
      { q: 'Was heißt es, wenn etwas <u>im Angebot</u> ist?', o: ['Es ist diese Woche billiger.', 'Es ist ausverkauft.', 'Man kann darüber verhandeln.', 'Es gibt kein Pfand darauf.'], c: 0, e: 'Und es heißt <b>im</b> Angebot, nicht <i>auf</i>. Auch möglich: <i>Der Käse ist reduziert.</i>' },
      { q: 'Wann brauchst du eine <u>Quittung</u> statt eines Bons?', o: ['beim Handwerker oder Taxi', 'im Supermarkt', 'am Pfandautomaten', 'nie, das ist dasselbe'], c: 0, e: 'Die Quittung ist der offizielle Beleg mit Datum, Betrag und Unterschrift — für die Steuer und im Streitfall.' },
      { q: 'Wie steigert man <u>gut</u>?', o: ['gut — besser — am besten', 'gut — guter — am gutsten', 'gut — mehr gut — am meisten gut', 'gut — güter — am gütesten'], c: 0, e: 'Eine der vier Ausnahmen. Die anderen: viel — mehr — am meisten, gern — lieber — am liebsten, hoch — höher — am höchsten.' },
      { q: 'Am Regal stand ein niedrigerer Preis als an der Kasse. Was gilt?', o: ['Meistens der Preis am Regal — mit Bon.', 'Immer der Preis an der Kasse.', 'Der höhere Preis.', 'Man muss neu kaufen.'], c: 0, e: 'Sag es freundlich und zeig den Bon: <i>Am Regal stand ein anderer Preis, könnten Sie das bitte prüfen?</i> Meistens bekommst du die Differenz zurück.' }
    ],
    gap: [
      { t: 'Kochen ist billiger ___ bestellen.', o: ['als', 'wie', 'wenn', 'dass'], a: 'als' },
      { t: 'Das Brot ist genauso teuer ___ letzte Woche.', o: ['wie', 'als', 'denn', 'so'], a: 'wie' },
      { t: 'Für die Miete gebe ich ___ meisten aus.', o: ['am', 'im', 'zum', 'den'], a: 'am' },
      { t: 'Der Käse ist diese Woche ___ Angebot.', o: ['im', 'auf', 'in', 'am'], a: 'im' },
      { t: 'Auf der Flasche sind fünfundzwanzig Cent ___.', o: ['Pfand', 'Rabatt', 'Gebühr', 'Trinkgeld'], a: 'Pfand' },
      { t: 'Achtzehn fünfzig? ___ Sie zwanzig.', o: ['Machen', 'Geben', 'Nehmen', 'Zahlen'], a: 'Machen' },
      { t: 'Ohne ___ kann ich das leider nicht umtauschen.', o: ['Kassenbon', 'Pfand', 'Rabatt', 'Angebot'], a: 'Kassenbon' },
      { t: 'Der Markt ist ___ als der Supermarkt.', o: ['besser', 'gut', 'am besten', 'guter'], a: 'besser' }
    ],
    gbau: [
      { f: 'Bau den Vergleich:', t: ['Kochen', 'ist', 'billiger', 'als', 'bestellen'], l: ['Kochen', 'ist', 'billiger', 'als', 'bestellen'], e: 'Wo ein <b>-er</b> steht, folgt <b>als</b>. Das ist die ganze Regel für den Unterschied.' },
      { f: 'Bau den Satz mit Gleichheit:', t: ['Das', 'Brot', 'ist', 'genauso', 'teuer', 'wie', 'gestern'], l: ['Das', 'Brot', 'ist', 'genauso', 'teuer', 'wie', 'gestern'], e: 'Nach <b>genauso</b> steht <b>wie</b> — und das Adjektiv bleibt in der Grundform.' },
      { f: 'Bau den Höchstwert:', t: ['Am', 'meisten', 'gebe', 'ich', 'für', 'die', 'Miete', 'aus'], l: ['Am', 'meisten', 'gebe', 'ich', 'für', 'die', 'Miete', 'aus'], e: '<b>am meisten</b> ist die Ausnahme von <i>viel</i>. Und <i>ausgeben</i> ist trennbar — <i>aus</i> steht ganz hinten.' },
      { f: 'Bau den Satz an der Kasse:', t: ['Getrennt', 'bitte', 'ich', 'zahle', 'mit', 'Karte'], l: ['Getrennt', 'bitte', 'ich', 'zahle', 'mit', 'Karte'], e: 'Zwei kurze Sätze reichen. <b>Getrennt, bitte</b> versteht in Deutschland jede Bedienung.' }
    ],
    gstory: {
      t: 'Am Samstag war ich auf dem Markt. Das Gemüse dort ist deutlich billiger ___ im Supermarkt, und frischer ist es auch. Das Brot kostet allerdings genauso viel ___ beim Bäcker. ___ meisten gebe ich sowieso für Fleisch aus, deshalb kaufe ich es nur, wenn es ___ Angebot ist. An der Kasse habe ich gemerkt, dass der Preis höher war als am Regal, aber ich hatte den ___ noch in der Hand, und ich habe die Differenz zurückbekommen. Danach war ich noch am Pfandautomaten: zwanzig Flaschen, fünf Euro ___. Zu Hause habe ich alles aufgeschrieben, denn seit einem Monat führe ich Buch. Selbst kochen ist am ___, das sehe ich jetzt schwarz auf weiß.',
      o: ['als', 'wie', 'Am', 'im', 'Bon', 'Pfand', 'günstigsten', 'teurer'],
      a: [['als'], ['wie'], ['Am'], ['im'], ['Bon'], ['Pfand'], ['günstigsten']]
    }
  }
};
fs.writeFileSync(__dirname + '/../stunden/w11-a2-bezahlen-sparen.json', JSON.stringify(S, null, 2) + '\n', 'utf8');
console.log('geschrieben');
